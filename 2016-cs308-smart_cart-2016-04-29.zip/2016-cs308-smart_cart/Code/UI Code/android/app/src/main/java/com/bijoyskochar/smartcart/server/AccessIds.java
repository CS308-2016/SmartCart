package com.bijoyskochar.smartcart.server;

/**
 * The IDs
 * Created by BijoySingh on 3/22/2016.
 */
public class AccessIds {
    public static Integer GET_ORDER = 0;
    public static Integer CHANGE_ITEM = 1;
    public static Integer ADD_ORDER = 2;
    public static Integer SET_CANCELLED = 3;
    public static Integer SET_COMPLETED = 4;
}
