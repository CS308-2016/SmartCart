SmartCart
=========

The server for SmartCart, a project for an embedded systems lab course. 