2016 - CS308  Group 1 : Project SMART CART
================================================ 
 
Group Info: 
------------ 
+   Manik Dhar (120050006) 
+   Bijoy Singh Kochar (120050087) 
+   Nishanth Koushik (120050041)
+   Ranveer Aggarwal (120050020)
 
Extension Of 
------------ 
 
None
 
Project Description 
------------------- 
 
This is a reame template. It is written using markdown syntax. To know more about markdown you can alwats refer to [Daring Fireball](http://daringfireball.net/projects/markdown/basics).  
You can preview how your mardown looks when rendered [here](http://daringfireball.net/projects/markdown/dingus) 
 
Students are requested to use this format for the sake of uniformity and convinience. Also we can parse these files and then index them for easy searching.  
 
Technologies Used 
------------------- 
 
Remove the items that do no apply to your project and keep the remaining ones. 
 
+   Embedded C
+   Energia
+   Python 
+   Android 
    
 
 
Installation Instructions 
========================= 
 
+ For embedded system part need to install CCStudio, etc for TIVA and Energia library
+ For Django Server you need to install Python and PyCharm IDE
+ For Android Code you need to install Android Studio and add project in your Google Developer Console
 
Demonstration Video 
=========================  
Add the youtube link of the screencast of your project demo.

References 
=========== 
   
 
+ [Energia](http://energia.nu/)
+ [Android Studio](http://developer.android.com/sdk/index.html) 
+ [Django](https://www.djangoproject.com/) 
+ [PyCharm](https://www.jetbrains.com/pycharm/) 


