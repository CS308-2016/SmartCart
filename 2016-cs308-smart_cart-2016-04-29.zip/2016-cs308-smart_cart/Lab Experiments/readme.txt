Group A 
Manik Dhar (120050006)
Bijoy Singh Kochar (120050087)

Group B
Nishanth Koushik (120050041)
Ranveer Aggarwal (120050030)


Add a well documented and commented code of your experiments in the respective folders.
