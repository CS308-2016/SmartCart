Project Name: SMART CART

Team Members:
1. Manik Dhar (120050006)
2. Bijoy Singh Kochar (120050087)
3. Nishanth Koushik (120050041)
4. Ranveer Aggarwal (120050020)

Project Description:
Shopping is something we spend a lot of our time doing. How many of us have had the frustrating experience where even when purchases a few items, we have to stand in long queues. So we created a smart cart, which lets to securely add content which you wish to buy and purchase from your phone itself. We present the SMART CART project. #NoMoreLines 


Video Link:
https://youtu.be/eZmPLd2WPaA